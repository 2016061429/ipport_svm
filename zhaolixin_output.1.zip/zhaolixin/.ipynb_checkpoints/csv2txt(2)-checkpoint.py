import os
import math
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, LabelEncoder

root = 'data'      # csv数据放到data路径下
save = 'data_txt'  # txt保存到data_txt路径下
fetch_line = 128   # 每32行生成一个txt, 如果最后一个文件不够32行就不要了
max_length = 128   # 补全至512, 注意max_length必须大于字段总长

#* 创建文件目录
if not os.path.exists(save):
    os.makedirs(save)

# data目录下所有文件
files = os.listdir(root) 

# 不需要的字段， 可以自行添加
ignore_titles = [
    '@timestamp', '_@timestamp', '@version', '_index', '_score', '_type', 'bytes',
    'url', 'tags', 'ts.end', 'ts.start', 'type'

]


# 1. 找所有字段
col_titles = []
for ind, file in enumerate(files):
    # 文件路径
    file_path = os.path.join(root, file)  
    # 读取csv文件的内容
    contents = pd.read_csv(file_path, header=None, low_memory=False)
    # 列名
    titles   = contents.loc[0].values.tolist()  
    col_titles += titles

# 所有字段(无重复)
col_titles = sorted(list(set(col_titles)))
# 移除不需要的字段
col_titles = [c for c in col_titles if c not in ignore_titles]
# 保存有效字段
with open("titles.txt", 'w') as f:
    save_format = '\n'.join(col_titles)
    f.write(save_format)


# 2. 生成txt
# 使用OneHotEncoder进行独热编码
encoder = OneHotEncoder(sparse=False, handle_unknown="ignore")

# 遍历所有文件
for ind, file in enumerate(files):
    file_path = os.path.join(root, file)
    if not os.path.isfile(file_path):
        continue
    file_name = os.path.basename(file)[:-4]  # 文件名
    save_dir = os.path.join(save, file_name) # 以文件名命名的保存目录
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    # 读取csv文件的内容
    contents = pd.read_csv(file_path, header=None, low_memory=False)
    titles   = contents.loc[0].values.tolist()  # 列名
    # 移除不需要的字段
    titles_valid = [i for i, t in enumerate(titles) if t not in ignore_titles]

    # 所有特征
    # 空值转成字符
    contents.fillna('', inplace=True)
    data = contents[titles_valid]
    
    # 太大了会爆内存，这里每200个特征做一次onehot
    n_gap  = 16
    n_loop = math.ceil(len(data) / n_gap)
    counts = 0
    features = None
    for i in range(0, n_loop):
        if i == n_loop:
            a = data[ i*n_gap : -1]
        else:
            a = data[ i*n_gap : (i+1) * n_gap]
        encoded_features = encoder.fit_transform(a)
        if encoded_features.shape[0] < n_gap:
            continue
        encoded_features = encoded_features.astype('int')
        
        # 补齐0
        diff_len = max_length - encoded_features.shape[1]
        if diff_len <= 0:
            continue
        zero_matrix = np.zeros((encoded_features.shape[0], diff_len), dtype='int')
        padding_features = np.concatenate([encoded_features, zero_matrix], axis=1)

        if features is None:
            features = padding_features
        else:
            features = np.concatenate([features, padding_features])

        if features.shape[0] == fetch_line:
            # 保存txt文件
            save_to = os.path.join(save_dir, '{}.txt'.format(str(counts)))
            np.savetxt(save_to, features, fmt='%d')
            counts += 1
            features = None